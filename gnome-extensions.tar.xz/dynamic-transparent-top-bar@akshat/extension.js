import GLib from 'gi://GLib';
import Meta from 'gi://Meta';
import St from 'gi://St';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import { Extension } from 'resource:///org/gnome/shell/extensions/extension.js';

export default class DynamicTransparentTopBar extends Extension {
    enable() {
        this._trackedWindows = new Set();
        this._syncTimeoutId = null;
        this._isTransparent = null;

        // Workspace and display signals
        global.workspace_manager.connectObject(
            'active-workspace-changed', () => {
                this._updateTrackedWindows();
                this._queueSync();
            },
            this
        );

        global.display.connectObject(
            'restacked', () => {
                this._updateTrackedWindows();
                this._queueSync();
            },
            'window-entered-monitor', () => this._queueSync(),
            'window-left-monitor', () => this._queueSync(),
            this
        );

        // Overview signals
        Main.overview.connectObject(
            'showing', () => this._queueSync(),
            'hiding', () => this._queueSync(),
            this
        );

        // Initial setup
        this._updateTrackedWindows();
        this._sync();
    }

    disable() {
        if (this._syncTimeoutId) {
            GLib.Source.remove(this._syncTimeoutId);
            this._syncTimeoutId = null;
        }

        for (const win of this._trackedWindows) {
            win.disconnectObject(this);
        }
        this._trackedWindows.clear();

        global.workspace_manager.disconnectObject(this);
        global.display.disconnectObject(this);
        Main.overview.disconnectObject(this);

        if (Main.panel) {
            Main.panel.remove_style_class_name('dynamic-transparent-panel');
            Main.panel.remove_style_class_name('dynamic-solid-panel');
        }
        this._isTransparent = null;
    }

    _queueSync() {
        if (this._syncTimeoutId)
            return;

        this._syncTimeoutId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 16, () => {
            this._syncTimeoutId = null;
            this._sync();
            return GLib.SOURCE_REMOVE;
        });
    }

    _updateTrackedWindows() {
        for (const win of this._trackedWindows) {
            win.disconnectObject(this);
        }
        this._trackedWindows.clear();

        const activeWorkspace = global.workspace_manager.get_active_workspace();
        if (!activeWorkspace)
            return;

        const windows = activeWorkspace.list_windows();
        for (const win of windows) {
            win.connectObject(
                'notify::allocation', () => this._queueSync(),
                'position-changed', () => this._queueSync(),
                'size-changed', () => this._queueSync(),
                'unmanaged', () => {
                    this._trackedWindows.delete(win);
                    this._queueSync();
                },
                this
            );
            this._trackedWindows.add(win);
        }
    }

    _shouldBeTransparent() {
        if (Main.overview.visible)
            return true;

        const panel = Main.panel;
        if (!panel)
            return true;

        const monitor = Main.layoutManager.findMonitorForActor(panel) ?? Main.layoutManager.primaryMonitor;
        if (!monitor)
            return true;

        const activeWorkspace = global.workspace_manager.get_active_workspace();
        if (!activeWorkspace)
            return true;

        const panelHeight = panel.get_height() || 32;
        const scale = St.ThemeContext.get_for_stage(global.stage)?.scale_factor ?? 1;
        const topThreshold = monitor.y + panelHeight + (8 * scale);

        const windows = activeWorkspace.list_windows();
        for (const win of windows) {
            if (win.minimized || win.is_hidden() || !win.showing_on_its_workspace())
                continue;

            const type = win.get_window_type();
            if (type !== Meta.WindowType.NORMAL && type !== Meta.WindowType.DIALOG)
                continue;

            // Exclude desktop background managers (e.g. DING desktop icons)
            const appId = win.get_gtk_application_id?.() ?? '';
            if (appId.includes('ding'))
                continue;

            if (win.get_monitor() !== monitor.index)
                continue;

            const rect = win.get_frame_rect();
            if (rect.y <= topThreshold && (rect.y + rect.height) > monitor.y) {
                return false;
            }
        }

        return true;
    }

    _sync() {
        const transparent = this._shouldBeTransparent();
        if (this._isTransparent === transparent)
            return;

        this._isTransparent = transparent;
        if (transparent) {
            Main.panel.remove_style_class_name('dynamic-solid-panel');
            Main.panel.add_style_class_name('dynamic-transparent-panel');
        } else {
            Main.panel.remove_style_class_name('dynamic-transparent-panel');
            Main.panel.add_style_class_name('dynamic-solid-panel');
        }
    }
}
